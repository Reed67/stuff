#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

# FileHandler öffnet, schreibt, ließt und schließt die notwendigen Config Files
class FileHandler(object):
    def __init__(self, fileName):
        self.fileName = fileName
    def fileReader(self, mode='r'):
        self.f = open(fileName, mode)
        return self.f
    def fileWriter(self, options):
        f.write(options)
    def fileCloser(self):
        f.close()

# hält die Vhost config für verschiedene Vhost-Typen und übermittelt alle notwendigen schreibinfos
# für den Vhost an den ConfigFileHandler
class ApacheVhostFile(object):
    def __init__(self, VhostConfig):
        self.make()
    def make():
        pass

# schreibt das Vhost-Dir und alle nötigen Vhost-Dir Einträge und Symlinks
class FileVhostDir(object):
    def __init__(self, VhostConfig):
        self
    def make():
        pass

# objekt mit der vom Nutzer eingegeben spezifik für den Vhost
class VhostConfig(object):
    def __init__(self):
        self.options = dict()
        self.options['ApacheVhostPath'] = 'Path_to_Apache_Vhost_File'
        self.options['FileVhostPath'] = 'Path_to_Vhost'
    def get(self, key):
        return self.options.get(key, False)
    def set(self, key, option):
        self.options[key] = option

# Hauptsteuerung
class Main(object):
    def __init__(self):
        self.vhostconfig = VhostConfig()
    def setConfig(self, vhostName, vhostPort, enviroment = 'ph'):
        VhostConfig.set(self.vhostconfig, 'vhostName', vhostName)
        VhostConfig.set(self.vhostconfig, 'vhostPort', vhostPort)
        VhostConfig.set(self.vhostconfig, 'enviroment', enviroment)
    def buildVhost():
        ApacheVhostFile(self.VhostConfig)
        FileVhostDir(self.VhostConfig)

if len(sys.argv) == 4:
    argument3 = sys.argv[3]
else:
    argument3 = ''

main = Main()
main.setConfig(sys.argv[1], sys.argv[2], argument3)