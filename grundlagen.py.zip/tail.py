#!/data/p.lorenz/py_virtualenv/python_workshop/bin/python
# -*- coding: utf-8 -*-
import time

def tail(f):
	f.seek(0, 2) # ende des files suchen
	while True:
		line = f.readline()
		if not line:
			time.sleep(0.1)
			continue
		yield line

def grep(lines, searchtext):
	for line in lines:
		if searchtext in line: yield line

#wwwlog = tail(open('portfolio.csv'))
#pylines = grep(wwwlog, 'GOOG')
#for line in pylines:
#	print line;