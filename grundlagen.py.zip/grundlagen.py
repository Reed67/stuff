#!/data/p.lorenz/py_virtualenv/python_workshop/bin/python
# -*- coding: utf-8 -*-

### EINFÜHRUNG ###

# Guido von Rossum Niederländer
# 1989 als Weihnachtsprojekt gestartete Lehrsprache "Python" als ABC (Simula clon) nachfolger
# Diktator auf Lebenszeit was Python anbelangt, Vorsiztender der Python Software Foundation
# Arbeitet seit 2005 bei Google
# seit Dezember 2012 bei Dropbox
# BLOG: http://neopythonic.blogspot.de/

# Konsole von python
# > python oder >python3
# Hilfesystem in der python Konsole
# >>> help() oder >>> help(MODULNAME) für spezifische Hilfe

# Python und Coding Standards
# sind eingebaut und in der Community allgemein akzeptiert
# man versucht sich an das Zen of Python zu halten
# >>> import this

### GRUNDLAGEN ###

# print Statement mit automatischem Zeilenumruch
print 'Hello World'

# Hinweis Python 3 -> print() Funktion

# Schleifen und Einrückung
a = 1
b = 2

# Einrückungen sind wichtig, ohne diese werden Schleifen, Funktionen, Klassen nicht erkannt,
# es gibt keine Klammern um CODE BLÖCKE sichtbar zu machen
# dabei ist es egal wieviele Leerzeichen man verwendet, es muss nur im CODE-BLOCK einheitlich sein
# Tabs sollten übrigens nicht verwendet werden, geht aber
# GAG: >>> from __future__ import braces
if a > b:
	print b
elif a < b:
	print a
else:
	raise RuntimeError("Is not possible")

# bei kurzen, einzeiligen Anweisungen ist auch das möglich
if a > b:	print b
elif a < b:	print a
else:	raise RuntimeError("Is not possible")

### SRINGS UND QUATTYPEN ###

a = "Hello World"
b = 'Hello Leipzig'
# Triple-Quotes können über mehrer Zeilen gehen
c = """Say 'Hello'
to Unister"""

# print verkettet mit ,
print a, b, c

print a[1]

### MEHRZEILIGE KOMMANDOS ###

# Auch Kommandos können über mehrer Zeilen gehen, dazu wird zur zeilenverkettung \ benutzt
import math
x = 33.156
y = 2356.145
n = 2

a = math.cos(3 * (x - n)) + \
    math.sin(3 * (y - n))

print a

### TYPEN UND KONVERTIERUNG ###

# keine Implizite Typkonvertierung möglich, ein String bleibt ein String

x = "37"
y = '12'
# Verkettung über +
z = x + y

print "Verkettung von y und x als Strings: ", z

# Explizite Typkonvertierung über Funktionen int() oder float()

z = int(x) + int(y)

print "y und x als int-cast:", z

# zwei verschiedene Typen ergeben immer den genaueren Typ als Ergebniss

z = int(x) + float(y)

print "x als int und y als float:", z

# es sei den ich caste das Egebniss wieder

print "x als int und y als float und z als int-cast:", int(z)

# nicht String Zeichen kann ich auch per str(), repr() oder format() ausgeben
z = 3.9

print str(z)
# kein Fehler sondern floating-point Fehler der Rechnerarchitektur
print repr(z)
print format(z, "0.5f")

### LISTEN (veränderbar) ###
# leere Liste
names = list()
# Liste mit Namen
names = ["Peter", "Nico", 'Dave', """Klaus"""]

# häufig benutzte Schleife in Python
for name in names:
	print name

# Ersetzen eines List eintrages
names[3] = 'Kunibert'

print names

# Anhängen
names.append('Heike')
# Einfügen von Werten an die genante Stelle
names.insert(3, 'Kalle')

print names

# listen können beliebige Daten enthalten auch andere Listen

multi_list = [1, "Namen", 5000.354, ["Mark", 4000, [100, 1]], 12]

print multi_list

### TUPEL ###
#, unveränderbar gleichen operationen wie listen benötigen weniger Speicherplatz
person = ('Peter', 'Lorenz', '31')

first_name, last_name, age = person

print first_name, last_name, 'Alter', age

# Beispiel

filename = "portfolio.csv"

portfolio = []
for line in open(filename):
	fields = line.split(",")
	name = fields[0]
	shares = int(fields[1])
	print fields[2]
	price = float(fields[2])
	stock = (name,shares,price)
	portfolio.append(stock)

total = 0.0
for name, shares, price in portfolio:
	total += shares * price
	print "In Ihrem Protfolio sind Aktien der Firma", name, "im Wert von", total, "Somali Schilling"

### SETS'S ###
# ungeordnetet einzigartige Listen mit Objekten
s = set("Hello")
print s

s.add('x')
s.update('d','w','n')
print s

s.remove('d')
print s

### DICTIONARIES ###
# für PHP Programmierer, assoziative Arrays
# leeres Dictionarie
stock = dict()
#dictionarie mit Inhalt
stock = {
	'name' : 'GOOG',
	'shares': 100,
	'price' : 345.00
}
# Hinzufügen von Inhalten
stock['date'] = '12.12.2012'

# als Keys kann man tuple, zahlen, string oder auch andere Objekte verwenden
# sie sind eine gute möglichkeit um ungeordnete daten schnell zu durchforsten

prices = {
	'GOOG' : 490.10,
	'AAPL' : 123.12,
	'IBM'  : 91.50,
	'MSFT' : 52.13
}

if 'SCOX' in prices:
	p = prices['SCOX']
else:
	p = 0.0
print p

# oder schneller
p = prices.get('SCOX', 0.00)
print p

# um eine Liste aller Schlüssel eines dictonaries zu bekommen kann man das dictioniery in eine liste wandeln
syms = list(prices)
print syms

### FUNCTIONEN ###
# definieren und nutzen

def remainder(a,b):
	q = a // b
	r = a - q*b
	return r

print remainder(5, 4)

# default werte und mehrere Rückgabeparameter durch listen

def divide(a, b=2):
	q = a // b
	r = a - q*b
	return (q,r)

# durch das zuweisen der liste an 2 variablen kann ich die rückgabewerte auch gleich einzeln weiternutzen
quotient, rest = divide(12)
print quotient, rest

# Locale und globale Variablen

count = 0
def foo():
	global count
	count2 = 0

	count += 1
	count2 += 1

foo()
print count
# print count2

### GENERATOREN ###
# funktionen zum generieren von sequenzen

def countdown(n):
	print 'Countdown gestartet'
	while n > 0:
		yield n
		n -= 1

for i in countdown(5):
	print i

# siehe tail.py

### KLASSEN UND OBJEKTE ###
# alles in Python sind Objekte

item = [34, 12]
item.append(32)

# zeigt uns die möglichen Buildin funktionen des objektes
# __add__ z.B. implementiert das + Zeichen als add Operator, __contains__ steht für in
dir(item)

# Beispielklasse eines Stacks mit push, pop und längen operationen

class Stack(object): # Klasse namens Stack erbt von object (wurzel aller python typen)
	def __init__(self): # der Konstruktur
		self.stack = []
		# self steht hier für für das objekt selbst, alle operation die auf objekt attribute gemacht werden müssen auf self gemacht werden
        # self.stack ist so ein attribut
	def push(self, object):
		self.stack.append(object)
	def pop(self):
		return self.stack.pop()
	def lenght(self):
		return len(self.stack)

# Klasse nutzen

s = Stack()
print dir(s), '\n'

s.push('Me')
s.push(12)
s.push(['Dollar', 3, 4])
print 'Länge des Stacks', s.lenght()
print 'Element1', s.pop()
print 'Element2', s.pop()
print 'Länge des Stacks', s.lenght()
del s

### EXCEPTIONS ###
#try:
#	f = open("file_unknown.txt", "r")
#except IOError as e:
#	print e

# man kann auch selbst exceptions werfen
#raise RuntimeError("This is wrong")

# http://docs.python.org/2/library/exceptions.html Liste eingebauter Exceptiontypen und deren Hirarchie

### MODULE ###
# -> sind Auslagerungen von Klassen oder Funktionsdefinitionen die man importieren kann
import tail
print dir(tail)

# enthaltene Funktionen oder Klassen werden dann ganz normal benutzte
wwwlog = tail.tail(open('portfolio.csv'))
pylines = tail.grep(wwwlog, 'GOOG')
#for line in pylines:
#	print line;

# from tail import grep #um spezifische verweise zu importieren spart dann tail. ein
