<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="content-language" content="de">
<meta name="author" content="Olaf Thiele">
<meta name="generator" content="Notepad++">
<title>AJAX - JSON - Testdatei</title>
<!--
<link rel="stylesheet" type="text/css" href="style.css">
-->
<script>
function createRequest() {
    try {
        request = new XMLHttpRequest();
    }
    catch (e) {
        try {
            request = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e) {
            try {
                request = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (failed) {
                request = null;
            }
        }
    }
    return request;
}
function collectData(form) {
    var data = '';
    tmpArr = document.getElementById(form).getElementsByTagName('input');
    //for(var i = 0, j = tmpArr.length; i < j; i++) {
    for(var i = 0, j = 3; i < j; i++) {
        data = data + 'val_' + i + '=' + tmpArr[i].value + '&';
    }
    //console.log(data);
    return data;
}
function showResults() {
    if(req.readyState == 4 && req.status == 200) {
        doc.getElementById('result_area').innerText = req.responseText;
    }
}
function sendPostRequest(request, url, params, asynchronos) {
    request.open("POST", url, true);
    request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    request.onreadystatechange = showResults;
    request.send(params);
}
</script>
</head>
<body>
<form id="AJAXForm">
    <input id="val_0" data-el="1" value="" />
    <input id="val_1" data-el="2" value="" />
    <input id="val_2" data-el="3" value="" />
    <input id="sendPost" type="button" value="sendPost" />
</form>
<div id="result_area"></div>
<script>
var data, req, doc = document;
req = createRequest();
if( req === null ) {
    alert('AJAX konnte nicht initialisiert werden');
};
if( doc.getElementById('sendPost').addEventListener ) {
    doc.getElementById('sendPost').addEventListener('click', function() {
        sendPostRequest(req, 'req_post.php', collectData('AJAXForm'));
    });
} else {
    doc.getElementById('sendPost').onclick = function() {
        sendPostRequest(req, 'req_post.php', collectData('AJAXForm'));
    }
}
</script>
</body>
</html>
