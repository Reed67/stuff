<?php
if(!empty($_POST)) {
print_r($_POST);
}