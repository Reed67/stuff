<!DOCTYPE html>
<html lang="de">
    <head>
        <meta http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT">
        <meta http-equiv="Pragma" content="no-cache">
        <meta http-equiv="Cache-Control" content="no-cache">
        <meta http-equiv="Reply-to" content="olaf.thiele@unister.de">
        <meta charset="UTF-8">
        <meta name="author" content="Olaf Thiele">
        <meta name="generator" content="notepad++ portable">
        <meta name="description" content="Beispiel f�r einen AJAX GET Aufruf">
        <meta name="keywords" content="AJAX GET HTML5">
        <meta name="creation-date" content="08/29/2013">
        <meta name="revisit-after" content="15 days">
        <title>AJAX GET-Variante</title>
        <!--
        <link rel="stylesheet" type="text/css" href="my.css">
        -->
    </head>
    <body>
        <header>
            <h1>HTML 5 - AJAX GET Beispiel</h1>
        </header>
        <section>
            <article>
                <h1>Formular zum Versenden</h1>
                <p>Content</p>
                <form id="get_form">
                    <input id="val_0" name="val_0" value="">
                    <input type="button" id="send_form" form="get_form" value="Send" />
                    <input type="button" id="clear_values" form="get_form" value="Clear Values!" />
                </form>
            </article>
            <article>
                <h1>Daten zum Versenden</h1>
                <p id="send_data"></p>
            </article>
            <article>
                <h1>Ergebnis des Requests</h1>
                <p id="send_result">&nbsp;</p>
            </article>
        </section>
        <script src="scripts/javascript/get_request.js"></script>
        <script>
        var request, start_url = 'request.php', doc = document;
        /* creates the request variable */
        createRequest();
        /*
         * Shows the results of a request
         * 
         * main function for xmlhttprequest function load
         * @author Olaf Thiele <olaf.thiele@unister.de>
         * @version 1.0
         * @package AJAX
         * 
         */
        function handleResult() {
            if(request.readyState == 4 && request.status == 200) {
                while(doc.getElementById('send_result').hasChildNodes()) {
                    doc.getElementById('send_result').removeChild(doc.getElementById('send_result').firstChild);    
                }
                var tNode = doc.createTextNode(request.responseText);
                
                doc.getElementById('send_result').appendChild(tNode);
                //console.log(request.responseText);
            }
        } 
        /*
         * do the request
         * 
         * opens the request url and sends the request
         * @author Olaf Thiele <olaf.thiele@unister.de>
         * @version 1.0
         * @package AJAX
         * 
         */
        function doRequest() {
            showData();
            if(doc.getElementById('val_0').value !== '') {
                openRequest(request, start_url);
                sendRequest();            
            } else {
                while(doc.getElementById('send_data').hasChildNodes()) {
                    doc.getElementById('send_data').removeChild(doc.getElementById('send_data').firstChild);    
                }
                var tNode = doc.createTextNode('Nothing to send or val_0 not set!');
                doc.getElementById('send_data').appendChild(tNode);    
                
            }
        }
        /*
         * sets the data
         * 
         * sets the data paragraph for the data to send
         * @author Olaf Thiele <olaf.thiele@unister.de>
         * @version 1.0
         * @package AJAX
         * 
         */
        function showData() {          
            while(doc.getElementById('send_data').hasChildNodes()) {
                doc.getElementById('send_data').removeChild(doc.getElementById('send_data').firstChild);    
            }
            var tNode = doc.createTextNode(doc.getElementById('val_0').value);
            doc.getElementById('send_data').appendChild(tNode);    
        }
        /*
         * clears the values
         * 
         * clears the values in the result fields
         * @author Olaf Thiele <olaf.thiele@unister.de>
         * @version 1.0
         * @package AJAX
         * 
         */
        function clearData() {
            doc.getElementById('send_data').firstChild.data = '';            
            doc.getElementById('send_result').firstChild.data = '';            
        }
        /* add a eventhandler to the buttond 'send_form' */
        if(doc.getElementById('send_form').addEventListener) {
            doc.getElementById('send_form').addEventListener('click', doRequest);
        } else {
            doc.getElementById('send_form').onclick = doRequest;    
        }
        /* add a eventhandler to the buttond 'clear_values' */
        if(doc.getElementById('clear_values').addEventListener) {
            doc.getElementById('clear_values').addEventListener('click', clearData);
        } else {
            doc.getElementById('clear_values').onclick = clearData;    
        }
        </script>
    </body>
</html>                
