<?php
if(!empty($_GET)) {
    print_r($_GET);
}