/**
 * create request
 * 
 * Method for creating a XMLHttpRequest
 * 
 * @returns  object      a request-object for valid
 *                       null for invalid
 */
function createRequest() {
    try {
        request = new XMLHttpRequest();
    } catch (e) {
        try {
            request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (failed) {
                request = null;
            }
        }
    }
    return request;
}
/**
 * open request
 * 
 * Opens a XMLHttpRequest for a GET-request
 * 
 * @param    request     object      the request object
 * @param    params      string      parameter for get request
 * @param    async       boolean     true for asynchronous request
 *                                   false for synchronous request
 *                                   defaults to true
 * @param    user        string      user
 * @param    passwd      string      password for given user
 */
function openRequest(req, url, async, user, passwd) {
    async       = async         || true;
    user        = user          || undefined;
    passwd      = passwd        || undefined;
    url = 'scripts/php/' + url + '?val_0=' + doc.getElementById('val_0').value;
    if(user && passwd === undefined) {
        request.open('GET', url, async);
    } else {
        request.open('GET', url, async, user, passwd);
    }
    if(request.load) {
        request.addEventListener('load', handleResult);        
    } else {
        request.onreadystatechange = handleResult;
    }
}
/**
 * send request
 * 
 * sends a get request
 * 
 * 
 */
function sendRequest() {
    if( request === null ) {
        alert('A request could not be created!')
    } else {
        openRequest(request, start_url);
        request.send(null);        
    }
}
