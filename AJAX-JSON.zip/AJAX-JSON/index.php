<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="content-language" content="de">
<meta name="author" content="Olaf Thiele">
<meta name="generator" content="Notepad++">
<title>AJAX - JSON - Testdatei</title>
<!--
<link rel="stylesheet" type="text/css" href="style.css">
-->
</head>
<body>
<form>
    <input id="sendJSON" type="button" value="sendJSON" />
    <input id="getJSON" type="button" value="getJSON" />
</form>
<div id="values_to_send_area">
    <textarea id="values_to_send" cols="80" rows="6"></textarea>
</div>
<div id="values_to_response_area">
    <textarea id="values_to_response" cols="80" rows="6"></textarea>
</div>
<script>
function createRequest() {
    try {
        request = new XMLHttpRequest();
    }
    catch (e) {
        try {
            request = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e) {
            try {
                request = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (failed) {
                request = null;
            }
        }
    }
    return request;
}
function showResults() {
    if(req.readyState == 4 && req.status == 200) {
        var tmp = req.responseText;
        doc.getElementById('values_to_response').innerText = tmp;
    }
}
function showGetResults() {
    if(req.readyState == 4 && req.status == 200) {
        var tmp = req.responseText;
        doc.getElementById('values_to_response').innerText = tmp;
        json_obj = JSON.parse(tmp);
        console.log(json_obj.command);
        console.log(json_obj.values[0]);  
    }
}
function sendJSONRequest() {
    var json = {
        "id": "myJSON",
        "null_value": null,
        "object_value": {
            "id": "item_id",
            "item": "Itemtext"
            },
        "fields": ["test0 \\ \"", "test1", "test2"],
        "values": [1, 2]
        };
    var params = "val_0=" + JSON.stringify( json );
    doc.getElementById('values_to_send').value = params;
    request.open("POST", "req_JSON.php", true);
    request.setRequestHeader("Content-type","application/x-www-form-urlencoded;charset=UTF-8");
    request.onreadystatechange = showResults;
    request.send(params);
}
function sendJSONgetRequest() {
    var params = "";
    doc.getElementById('values_to_send').value = params;
    request.open("POST", "get_JSON.php", true);
    request.setRequestHeader("Content-type","application/x-www-form-urlencoded;charset=UTF-8");
    request.onreadystatechange = showGetResults;
    request.send(params);
}
</script>
<script>
var data, req, doc = document;
req = createRequest();
if( req === null ) {
    alert('AJAX konnte nicht initialisiert werden');
};
if( doc.getElementById('sendJSON').addEventListener ) {
    doc.getElementById('sendJSON').addEventListener('click', function() {
        sendJSONRequest();
    });
} else {
    doc.getElementById('sendJSON').onclick = function() {
        sendJSONRequest();
    }
}
if( doc.getElementById('getJSON').addEventListener ) {
    doc.getElementById('getJSON').addEventListener('click', function() {
        sendJSONgetRequest();
    });
} else {
    doc.getElementById('getJSON').onclick = function() {
        sendJSONgetRequest();
    }
}
</script>
</body>
</html>
