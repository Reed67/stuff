<?php
$val = json_decode($_POST['val_0']);
print_r($val);
print_r($val->{"id"} . "\n");
print_r($val->{"object_value"}->{"id"} . "\n");
print_r($val->fields[0] . "\n");
