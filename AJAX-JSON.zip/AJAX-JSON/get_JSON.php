<?php
$val = (object)null;
$val->command = 'setName';
$val->values[] = 'Hans';
$val->values[] = 'Mustermann';
$json_str = json_encode($val);
echo $json_str;

